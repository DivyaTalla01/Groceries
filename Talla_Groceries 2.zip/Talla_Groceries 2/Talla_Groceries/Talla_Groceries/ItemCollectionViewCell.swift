//
//  ItemCollectionViewCell.swift
//  Talla_Groceries
//
//  Created by Divya on 4/16/24.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    func assignItem(with i:Item){
        imageViewOL.image = i.image
    }
}
