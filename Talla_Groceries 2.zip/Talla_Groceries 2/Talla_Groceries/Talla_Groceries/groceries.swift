//
//  groceries.swift
//  Talla_Groceries
//
//  Created by Divya on 4/16/24.
//

import Foundation
import UIKit

// Define the struct
struct Item {
    var itemName: String
    var image: UIImage
    var itemPrice: Double
    var itemExpiry: String
    var itemQuantity: Int
    var itemOrigin: String
    var itemDescription: String
}

// Generate Data for Fruits
let fruits: [Item] = [
    Item(itemName: "Apple", image: UIImage(named: "apple")!, itemPrice: 1.99, itemExpiry: "2024-04-18", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Fresh, juicy apples"),
    Item(itemName: "Banana", image: UIImage(named: "banana")!, itemPrice: 0.49, itemExpiry: "2024-04-15", itemQuantity: 15, itemOrigin: "Ecuador", itemDescription: "Ripe yellow bananas"),
    Item(itemName: "Orange", image: UIImage(named: "orange")!, itemPrice: 0.79, itemExpiry: "2024-04-16", itemQuantity: 8, itemOrigin: "Florida", itemDescription: "Sweet, tangy oranges"),
    Item(itemName: "Grapes", image: UIImage(named: "grapes")!, itemPrice: 2.99, itemExpiry: "2024-04-20", itemQuantity: 6, itemOrigin: "California", itemDescription: "Juicy, seedless grapes"),
    Item(itemName: "Strawberry", image: UIImage(named: "strawberry")!, itemPrice: 3.49, itemExpiry: "2024-04-19", itemQuantity: 10, itemOrigin: "Mexico", itemDescription: "Fresh, red strawberries"),
    Item(itemName: "Pineapple", image: UIImage(named: "pineapple")!, itemPrice: 2.99, itemExpiry: "2024-04-21", itemQuantity: 8, itemOrigin: "Hawaii", itemDescription: "Sweet, tropical pineapple"),
        Item(itemName: "Mango", image: UIImage(named: "mango")!, itemPrice: 1.79, itemExpiry: "2024-04-20", itemQuantity: 12, itemOrigin: "India", itemDescription: "Juicy, ripe mangoes"),
        Item(itemName: "Watermelon", image: UIImage(named: "watermelon")!, itemPrice: 3.99, itemExpiry: "2024-04-22", itemQuantity: 5, itemOrigin: "USA", itemDescription: "Refreshing, seedless watermelon"),
        Item(itemName: "Kiwi", image: UIImage(named: "kiwi")!, itemPrice: 0.99, itemExpiry: "2024-04-19", itemQuantity: 9, itemOrigin: "New Zealand", itemDescription: "Tangy, green kiwi fruit"),
        Item(itemName: "Peach", image: UIImage(named: "peach")!, itemPrice: 1.29, itemExpiry: "2024-04-20", itemQuantity: 7, itemOrigin: "Georgia", itemDescription: "Juicy, ripe peaches")
]

// Generate Data for Vegetables
let vegetables: [Item] = [
    Item(itemName: "Carrot", image: UIImage(named: "carrot")!, itemPrice: 0.79, itemExpiry: "2024-04-16", itemQuantity: 8, itemOrigin: "California", itemDescription: "Fresh, crunchy carrots"),
    Item(itemName: "Broccoli", image: UIImage(named: "broccoli")!, itemPrice: 1.29, itemExpiry: "2024-04-17", itemQuantity: 6, itemOrigin: "Mexico", itemDescription: "Nutritious broccoli florets"),
    Item(itemName: "Spinach", image: UIImage(named: "spinach")!, itemPrice: 1.49, itemExpiry: "2024-04-15", itemQuantity: 5, itemOrigin: "USA", itemDescription: "Fresh, green spinach leaves"),
    Item(itemName: "Tomato", image: UIImage(named: "tomato")!, itemPrice: 0.99, itemExpiry: "2024-04-18", itemQuantity: 8, itemOrigin: "California", itemDescription: "Ripe, red tomatoes"),
    Item(itemName: "Cucumber", image: UIImage(named: "cucumber")!, itemPrice: 0.69, itemExpiry: "2024-04-20", itemQuantity: 6, itemOrigin: "Mexico", itemDescription: "Crunchy, refreshing cucumbers"),
    Item(itemName: "Bell Pepper", image: UIImage(named: "bell_pepper")!, itemPrice: 0.89, itemExpiry: "2024-04-21", itemQuantity: 6, itemOrigin: "Spain", itemDescription: "Colorful bell peppers"),
       Item(itemName: "Onion", image: UIImage(named: "onion")!, itemPrice: 0.59, itemExpiry: "2024-04-23", itemQuantity: 10, itemOrigin: "USA", itemDescription: "Versatile onions"),
       Item(itemName: "Potato", image: UIImage(named: "potato")!, itemPrice: 0.49, itemExpiry: "2024-04-25", itemQuantity: 15, itemOrigin: "Idaho", itemDescription: "Starchy potatoes"),
       Item(itemName: "Zucchini", image: UIImage(named: "zucchini")!, itemPrice: 0.79, itemExpiry: "2024-04-22", itemQuantity: 7, itemOrigin: "California", itemDescription: "Tender zucchinis"),
       Item(itemName: "Green Beans", image: UIImage(named: "green_beans")!, itemPrice: 1.19, itemExpiry: "2024-04-23", itemQuantity: 5, itemOrigin: "USA", itemDescription: "Crunchy green beans")
   
]

// Generate Data for Dairy
let dairy: [Item] = [
    Item(itemName: "Milk", image: UIImage(named: "milk")!, itemPrice: 2.49, itemExpiry: "2024-04-14", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Fresh, whole milk"),
    Item(itemName: "Cheese", image: UIImage(named: "cheese")!, itemPrice: 3.99, itemExpiry: "2024-04-20", itemQuantity: 1, itemOrigin: "Italy", itemDescription: "Imported cheese selection"),
    Item(itemName: "Yogurt", image: UIImage(named: "yogurt")!, itemPrice: 1.99, itemExpiry: "2024-04-16", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Creamy, Greek yogurt"),
    Item(itemName: "Butter", image: UIImage(named: "butter")!, itemPrice: 2.29, itemExpiry: "2024-04-19", itemQuantity: 1, itemOrigin: "Local Dairy Farm", itemDescription: "Rich, creamy butter"),
    Item(itemName: "Eggs", image: UIImage(named: "eggs")!, itemPrice: 1.79, itemExpiry: "2024-04-18", itemQuantity: 12, itemOrigin: "Local Farm", itemDescription: "Farm-fresh eggs"),
    Item(itemName: "Almond Milk", image: UIImage(named: "almond_milk")!, itemPrice: 3.29, itemExpiry: "2024-04-23", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Nutritious almond milk alternative"),
        Item(itemName: "Goat Cheese", image: UIImage(named: "goat_cheese")!, itemPrice: 4.49, itemExpiry: "2024-04-25", itemQuantity: 1, itemOrigin: "France", itemDescription: "Creamy, tangy goat cheese"),
        Item(itemName: "Sour Cream", image: UIImage(named: "sour_cream")!, itemPrice: 1.79, itemExpiry: "2024-04-22", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Tangy sour cream"),
        Item(itemName: "Whipped Cream", image: UIImage(named: "whipped_cream")!, itemPrice: 3.49, itemExpiry: "2024-04-19", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Light, fluffy whipped cream"),
        Item(itemName: "Condensed Milk", image: UIImage(named: "condensed_milk")!, itemPrice: 1.99, itemExpiry: "2024-04-21", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Sweet condensed milk")
]

// Generate Data for Grains
let grains: [Item] = [
    Item(itemName: "Rice", image: UIImage(named: "rice")!, itemPrice: 1.99, itemExpiry: "2024-04-25", itemQuantity: 5, itemOrigin: "India", itemDescription: "Basmati rice grains"),
    Item(itemName: "Bread", image: UIImage(named: "bread")!, itemPrice: 2.49, itemExpiry: "2024-04-14", itemQuantity: 1, itemOrigin: "Local Bakery", itemDescription: "Freshly baked bread loaf"),
    Item(itemName: "Pasta", image: UIImage(named: "pasta")!, itemPrice: 1.99, itemExpiry: "2024-04-16", itemQuantity: 2, itemOrigin: "Italy", itemDescription: "Imported pasta selection"),
    Item(itemName: "Oats", image: UIImage(named: "oats")!, itemPrice: 3.29, itemExpiry: "2024-04-17", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Whole grain oats"),
    Item(itemName: "Quinoa", image: UIImage(named: "quinoa")!, itemPrice: 4.99, itemExpiry: "2024-04-20", itemQuantity: 1, itemOrigin: "Peru", itemDescription: "Nutritious quinoa seeds"),
    Item(itemName: "Barley", image: UIImage(named: "barley")!, itemPrice: 2.79, itemExpiry: "2024-04-23", itemQuantity: 1, itemOrigin: "Canada", itemDescription: "Nutty barley grains"),
        Item(itemName: "Cornmeal", image: UIImage(named: "cornmeal")!, itemPrice: 1.49, itemExpiry: "2024-04-22", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Fine cornmeal for baking"),
        Item(itemName: "Wheat Flour", image: UIImage(named: "wheat_flour")!, itemPrice: 2.99, itemExpiry: "2024-04-21", itemQuantity: 1, itemOrigin: "USA", itemDescription: "High-quality wheat flour"),
        Item(itemName: "Brown Rice", image: UIImage(named: "brown_rice")!, itemPrice: 2.49, itemExpiry: "2024-04-24", itemQuantity: 3, itemOrigin: "USA", itemDescription: "Healthy brown rice"),
        Item(itemName: "Couscous", image: UIImage(named: "couscous")!, itemPrice: 3.99, itemExpiry: "2024-04-20", itemQuantity: 1, itemOrigin: "Morocco", itemDescription: "Versatile couscous grains")
]

// Generate Data for Meats
let meats: [Item] = [
    Item(itemName: "Chicken", image: UIImage(named: "chicken")!, itemPrice: 5.99, itemExpiry: "2024-04-17", itemQuantity: 2, itemOrigin: "Local Farm", itemDescription: "Skinless, boneless chicken breast"),
    Item(itemName: "Beef", image: UIImage(named: "beef")!, itemPrice: 8.99, itemExpiry: "2024-04-20", itemQuantity: 2, itemOrigin: "Australia", itemDescription: "Grass-fed beef steak"),
    Item(itemName: "Pork", image: UIImage(named: "pork")!, itemPrice: 6.49, itemExpiry: "2024-04-18", itemQuantity: 2, itemOrigin: "Local Farm", itemDescription: "Tender, juicy pork chops"),
    Item(itemName: "Salmon", image: UIImage(named: "salmon")!, itemPrice: 10.99, itemExpiry: "2024-04-16", itemQuantity: 1, itemOrigin: "Alaska", itemDescription: "Fresh, wild-caught salmon fillet"),
    Item(itemName: "Shrimp", image: UIImage(named: "shrimp")!, itemPrice: 12.99, itemExpiry: "2024-04-19", itemQuantity: 1, itemOrigin: "Gulf of Mexico", itemDescription: "Jumbo, succulent shrimp"),
    Item(itemName: "Lamb", image: UIImage(named: "lamb")!, itemPrice: 9.49, itemExpiry: "2024-04-21", itemQuantity: 1, itemOrigin: "New Zealand", itemDescription: "Tender lamb chops"),
       Item(itemName: "Turkey", image: UIImage(named: "turkey")!, itemPrice: 7.99, itemExpiry: "2024-04-22", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Whole roasted turkey"),
       Item(itemName: "Duck", image: UIImage(named: "duck")!, itemPrice: 11.49, itemExpiry: "2024-04-23", itemQuantity: 1, itemOrigin: "France", itemDescription: "Delicious duck breast"),
       Item(itemName: "Veal", image: UIImage(named: "veal")!, itemPrice: 13.99, itemExpiry: "2024-04-24", itemQuantity: 1, itemOrigin: "Italy", itemDescription: "Tender veal cutlets"),
       Item(itemName: "Bison", image: UIImage(named: "bison")!, itemPrice: 14.99, itemExpiry: "2024-04-25", itemQuantity: 1, itemOrigin: "USA", itemDescription: "Lean bison meat")
]

// Array to store categories along with their respective item lists to retrieve data in collection view.
let allCategories: [[Item]] = [fruits, vegetables, dairy, grains, meats]

// Array to store all category names to display in the table view and as title in the second view.
let categoryNames: [String] = ["Fruits", "Vegetables", "Dairy", "Grains", "Meats"]
