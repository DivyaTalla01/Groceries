//
//  GroceriesViewController.swift
//  Talla_Groceries
//
//  Created by Divya on 4/16/24.
//

import UIKit

class GroceriesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {


    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return item.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = itemCollectionView.dequeueReusableCell(withReuseIdentifier: "viewCell", for: indexPath) as! ItemCollectionViewCell
        let currentItem = item[indexPath.row] // Access the item for the current index
            
            // Configure the cell using the current item
        cell.assignItem(with: currentItem)

            
            return cell


        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignItemDetails(index: indexPath)
    }
    func assignItemDetails(index: IndexPath){
        itemNameLabel.text = "Product Name:\(item[(index.row)].itemName)"
        itemPriceLabel.text = "Price $:\(String(item[(index.row)].itemPrice))"
        itemExpireLabel.text = "Expires On:\(item[(index.row)].itemExpiry)"
        itemDescriptionLabel.text = "Description:\(item[(index.row)].itemDescription)"
        itemQuantityLabel.text = "Qunatity:\(String(item[(index.row)].itemQuantity))"
        itemOriginLabel.text = "Origin:\(item[(index.row)].itemOrigin)"    }
    
    @IBOutlet weak var itemNameLabel: UILabel!
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    @IBOutlet var itemExpireLabel: UILabel!
    
    @IBOutlet weak var itemDescriptionLabel: UILabel!
    
    @IBOutlet weak var itemQuantityLabel: UILabel!
    
    @IBOutlet weak var itemOriginLabel: UILabel!
    
    @IBOutlet weak var itemCollectionView: UICollectionView!
    
    var item : [Item] = []
    
    var titleName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        itemNameLabel.text = "Product Name:\(item[0].itemName)"
        itemPriceLabel.text = "Price $:\(String(item[0].itemPrice))"
        itemExpireLabel.text = "Expires On:\(item[0].itemExpiry)"
        itemDescriptionLabel.text = "Description:\(item[0].itemDescription)"
        itemQuantityLabel.text = "Qunatity:\(String(item[0].itemQuantity))"
        itemOriginLabel.text = "Origin:\(item[0].itemOrigin)"

        // Do any additional setup after loading the view.
        itemCollectionView.delegate = self
        itemCollectionView.dataSource = self
        self.title = titleName
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
